Project for Axis Bank Screening

STEP 1:Open the signup.html To proceed.
STEP 2:Dont'enter name as (name or fname) in the signup.html It will show the error